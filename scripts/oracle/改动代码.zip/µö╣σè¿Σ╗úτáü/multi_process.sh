nohup python run.py 2>&1 > output.txt &
nohup python run1.py 2>&1 > output.txt &